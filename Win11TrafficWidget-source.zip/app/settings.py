from pathlib import Path
from PySide6.QtWidgets import QDialog, QVBoxLayout, QHBoxLayout, QLabel, QComboBox, QPushButton, QDoubleSpinBox, QCheckBox, QFontComboBox, QSlider, QFileDialog, QColorDialog
from PySide6.QtCore import Qt
from PySide6.QtGui import QColor
from .autostart import set_enabled, is_enabled
from .storage import save


class Settings(QDialog):
    def __init__(self, state, widget, parent=None):
        super().__init__(parent)
        self.state, self.widget = state, widget
        self.setWindowTitle('外观与设置')
        self.setMinimumWidth(380)
        self.setStyleSheet('QDialog {background:#202938;color:#edf4ff} QPushButton,QComboBox,QDoubleSpinBox,QFontComboBox {padding:6px;border-radius:8px;background:#344153;color:#fff} QLabel,QCheckBox {color:#edf4ff}')
        layout = QVBoxLayout(self)
        self.limit = QDoubleSpinBox(); self.limit.setRange(0.1, 100000); self.limit.setDecimals(1); self.limit.setValue(state['limit_gb']); self.limit.setSuffix(' GB')
        self.add_row(layout, '每月限额', self.limit)
        self.theme = QComboBox(); self.theme.addItems(['深色','浅色','自定义纯色']); self.theme.setCurrentIndex(['dark','light','custom'].index(state['theme']))
        self.add_row(layout, '主题', self.theme)
        self.bg = QPushButton('选择背景颜色'); self.bg.clicked.connect(lambda: self.pick('background'))
        self.add_row(layout, '背景颜色', self.bg)
        self.img = QPushButton('选择背景图片'); self.img.clicked.connect(self.choose_image)
        self.add_row(layout, '背景图片', self.img)
        clear = QPushButton('清除背景图片'); clear.clicked.connect(lambda: self.set_image('')); layout.addWidget(clear)
        self.font = QFontComboBox(); self.font.setCurrentFont(state['font']); self.add_row(layout, '字体', self.font)
        self.fg = QPushButton('选择主文字颜色'); self.fg.clicked.connect(lambda: self.pick('text_color')); layout.addWidget(self.fg)
        self.value = QPushButton('选择数值颜色'); self.value.clicked.connect(lambda: self.pick('value_color')); layout.addWidget(self.value)
        self.alpha = QSlider(Qt.Orientation.Horizontal); self.alpha.setRange(25,100); self.alpha.setValue(round(state['opacity']*100)); self.add_row(layout,'窗口透明度',self.alpha)
        self.source = QComboBox(); self.source.addItems(['本机累计（所有网卡）', 'Windows 统计（当前连接）']); self.source.setCurrentIndex(1 if state.get('usage_source') == 'windows' else 0)
        self.add_row(layout, '用量来源', self.source)
        self.small = QComboBox(); self.small.addItems(['本月剩余', '下载速度', '今日已用']); self.small.setCurrentIndex({'remaining': 0, 'speed': 1, 'daily': 2}.get(state.get('small_field'), 0))
        self.add_row(layout, '极小窗口优先显示', self.small)
        self.start = QCheckBox('开机自动启动'); self.start.setChecked(is_enabled()); layout.addWidget(self.start)
        apply = QPushButton('保存并应用'); apply.clicked.connect(self.apply); layout.addWidget(apply)

    @staticmethod
    def add_row(layout, label, control):
        row = QHBoxLayout(); row.addWidget(QLabel(label)); row.addWidget(control); layout.addLayout(row)

    def pick(self, key):
        color = QColorDialog.getColor(QColor(self.state[key]), self)
        if color.isValid():
            self.state[key] = color.name()
            if key == 'background': self.theme.setCurrentIndex(2)

    def choose_image(self):
        path, _ = QFileDialog.getOpenFileName(self,'选择背景图片',str(Path.home()),'Images (*.png *.jpg *.jpeg *.webp *.bmp)')
        if path: self.set_image(path)

    def set_image(self, path):
        self.state['image'] = path
        self.img.setText(Path(path).name if path else '选择背景图片')

    def apply(self):
        self.state.update(limit_gb=self.limit.value(), theme=['dark','light','custom'][self.theme.currentIndex()], font=self.font.currentFont().family(), opacity=self.alpha.value()/100, small_field=['remaining', 'speed', 'daily'][self.small.currentIndex()], usage_source='windows' if self.source.currentIndex() else 'local')
        if self.state['theme'] == 'light' and self.state['text_color'] == '#e6eef9':
            self.state['text_color'] = '#172232'
        elif self.state['theme'] == 'dark' and self.state['text_color'] == '#172232':
            self.state['text_color'] = '#e6eef9'
        try:
            set_enabled(self.start.isChecked())
        except OSError as exc:
            from PySide6.QtWidgets import QMessageBox
            QMessageBox.warning(self,'自启设置失败',str(exc))
            return
        self.state['autostart'] = self.start.isChecked()
        self.widget.setWindowOpacity(self.state['opacity'])
        self.widget.update()
        save(self.state)
        self.accept()
