"""Reassert the widget's topmost Z-order only when a taskbar obscures it."""
import ctypes
from ctypes import wintypes

_user32 = ctypes.WinDLL('user32', use_last_error=True)
_CALLBACK = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)


class RECT(ctypes.Structure):
    _fields_ = [('left', wintypes.LONG), ('top', wintypes.LONG),
                ('right', wintypes.LONG), ('bottom', wintypes.LONG)]


_user32.EnumWindows.argtypes = [_CALLBACK, wintypes.LPARAM]
_user32.EnumWindows.restype = wintypes.BOOL
_user32.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
_user32.GetClassNameW.restype = ctypes.c_int
_user32.IsWindowVisible.argtypes = [wintypes.HWND]
_user32.IsWindowVisible.restype = wintypes.BOOL
_user32.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(RECT)]
_user32.GetWindowRect.restype = wintypes.BOOL
_user32.GetTopWindow.argtypes = [wintypes.HWND]
_user32.GetTopWindow.restype = wintypes.HWND
_user32.GetWindow.argtypes = [wintypes.HWND, ctypes.c_uint]
_user32.GetWindow.restype = wintypes.HWND
_user32.SetWindowPos.argtypes = [wintypes.HWND, wintypes.HWND, ctypes.c_int, ctypes.c_int,
                                 ctypes.c_int, ctypes.c_int, ctypes.c_uint]
_user32.SetWindowPos.restype = wintypes.BOOL

_TASKBARS = {'Shell_TrayWnd', 'Shell_SecondaryTrayWnd'}
_GW_HWNDNEXT = 2
_SWP_NOSIZE = 0x0001
_SWP_NOMOVE = 0x0002
_SWP_NOACTIVATE = 0x0010


def _overlaps(a, b):
    return a.left < b.right and a.right > b.left and a.top < b.bottom and a.bottom > b.top


def keep_above_taskbar(widget):
    if not widget.isVisible():
        return
    hwnd = int(widget.winId())
    rect = RECT()
    if not _user32.GetWindowRect(hwnd, ctypes.byref(rect)):
        return
    taskbars = set()

    @_CALLBACK
    def collect(candidate, _):
        if _user32.IsWindowVisible(candidate):
            name = ctypes.create_unicode_buffer(64)
            if _user32.GetClassNameW(candidate, name, len(name)) and name.value in _TASKBARS:
                other = RECT()
                if _user32.GetWindowRect(candidate, ctypes.byref(other)) and _overlaps(rect, other):
                    taskbars.add(int(candidate))
        return True

    _user32.EnumWindows(collect, 0)
    if not taskbars:
        return
    # EnumWindows is not itself ordered by Z-order. Traverse from the top.
    candidate = _user32.GetTopWindow(None)
    for _ in range(4096):
        if not candidate or int(candidate) == hwnd:
            return
        if int(candidate) in taskbars:
            # No focus/position/size change: move only above other topmost windows.
            _user32.SetWindowPos(hwnd, wintypes.HWND(-1), 0, 0, 0, 0,
                                 _SWP_NOMOVE | _SWP_NOSIZE | _SWP_NOACTIVATE)
            return
        candidate = _user32.GetWindow(candidate, _GW_HWNDNEXT)
