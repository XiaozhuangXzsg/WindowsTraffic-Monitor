import json
import os
from pathlib import Path

BASE = Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / 'Win11TrafficWidget'
FILE = BASE / 'state.json'
DEFAULT = dict(layout_version=8, small_field='remaining', limit_gb=200.0, theme='dark', background='#182333', image='', font='Segoe UI', text_color='#e6eef9', value_color='#65d9ff', opacity=0.94, autostart=False, usage_source='local', visible=True, compact=False, width=190, height=74, x=None, y=None, day='', month='', daily=0, monthly=0, last_total=None)


def load():
    try:
        data = json.loads(FILE.read_text(encoding='utf-8'))
        state = {**DEFAULT, **data}
        if state.get('layout_version', 0) < 8:
            state.update(layout_version=8, width=190, height=74)
        return state
    except (OSError, ValueError, TypeError):
        return DEFAULT.copy()


def save(data):
    BASE.mkdir(parents=True, exist_ok=True)
    temp = FILE.with_suffix('.tmp')
    temp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    os.replace(temp, FILE)
