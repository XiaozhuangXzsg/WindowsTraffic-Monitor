"""Read Windows connection-profile usage without touching its private database."""
import asyncio
from datetime import datetime, timezone
from PySide6.QtCore import QThread, Signal


class UsageReader(QThread):
    result = Signal(object, str)

    def run(self):
        try:
            from winrt.windows.networking.connectivity import (
                NetworkInformation, NetworkUsageStates, DataUsageGranularity
            )
            profile = NetworkInformation.get_internet_connection_profile()
            if profile is None:
                self.result.emit(None, '没有可用的 Internet 连接配置文件')
                return
            now = datetime.now().astimezone()
            today = now.replace(hour=0, minute=0, second=0, microsecond=0)
            month = today.replace(day=1)
            states = NetworkUsageStates()
            # Queries are independent; never add overlapping daily and monthly totals.
            async def total(start):
                operation = profile.get_network_usage_async(
                    start.astimezone(timezone.utc), now.astimezone(timezone.utc),
                    DataUsageGranularity.TOTAL, states
                )
                rows = await asyncio.wait_for(operation, timeout=8)
                return sum(int(row.bytes_received) + int(row.bytes_sent) for row in rows)
            async def read():
                return await total(today), await total(month)
            daily, monthly = asyncio.run(read())
            name = profile.profile_name or '当前网络'
            self.result.emit({'daily': daily, 'monthly': monthly,
                              'month': now.strftime('%Y-%m'), 'day': now.strftime('%Y-%m-%d'),
                              'profile': name}, '')
        except ImportError:
            self.result.emit(None, '未安装 Windows 统计组件：请安装 requirements-windows.txt')
        except (OSError, RuntimeError, ValueError, TimeoutError) as exc:
            self.result.emit(None, f'Windows 统计不可用：{exc}')
