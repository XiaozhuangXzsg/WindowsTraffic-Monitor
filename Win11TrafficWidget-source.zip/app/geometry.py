"""Keep part of a floating window reachable; never snap it to an edge."""

def keep_reachable(x, y, width, height, left, top, right, bottom):
    visible = min(24, width, height)
    x = max(left - width + visible, min(right - visible + 1, x))
    y = max(top, min(bottom - visible + 1, y))
    return x, y
