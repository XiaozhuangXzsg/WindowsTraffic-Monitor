from PySide6.QtCore import Qt, QRectF, QEvent, QSize
from PySide6.QtGui import QColor, QPainter, QPainterPath, QPixmap, QFont, QFontMetrics, QImageReader, QCursor
from PySide6.QtWidgets import QWidget, QApplication
from .monitor import size
from .layout import layout_for, remaining_text
from .geometry import keep_reachable


class Widget(QWidget):
    MIN_WIDTH = 84
    MIN_HEIGHT = 28
    MAX_WIDTH = 460
    MAX_HEIGHT = 300

    def __init__(self, state):
        super().__init__()
        self.state = state
        self.speed = 0
        self.drag = None
        self.resizing = False
        self.resize_origin = None
        self.system_usage = None
        self.image_key = None
        self.image_pixmap = QPixmap()
        self.original_image = QPixmap()
        self.original_path = None
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint | Qt.WindowType.Tool)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setMaximumSize(self.MAX_WIDTH, self.MAX_HEIGHT)
        self.resize(112, 112) if state['compact'] else self.resize(min(self.MAX_WIDTH, max(self.MIN_WIDTH, int(state.get('width', 190)))), min(self.MAX_HEIGHT, max(self.MIN_HEIGHT, int(state.get('height', 74)))))
        screen = QApplication.primaryScreen().geometry()
        self.move(state['x'] if state['x'] is not None else screen.right()-self.width()-24,
                  state['y'] if state['y'] is not None else screen.top()+80)
        self.setToolTip('自由拖动；拖动右下角缩放；双击切换圆形模式')

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        compact = self.state['compact']
        radius = self.width()/2 if compact else min(18, self.height()/2)
        rect = QRectF(1, 1, self.width()-2, self.height()-2)
        path = QPainterPath()
        path.addRoundedRect(rect, radius, radius)
        p.setClipPath(path)
        bg = self.state['background'] if self.state['theme'] == 'custom' else ('#182333' if self.state['theme'] == 'dark' else '#f2f6fc')
        p.fillPath(path, QColor(bg))
        image = self.state.get('image', '')
        key = (image, self.width(), self.height())
        if image != self.original_path:
            self.original_path = image
            if image:
                reader = QImageReader(image)
                original_size = reader.size()
                if original_size.isValid():
                    reader.setScaledSize(original_size.scaled(QSize(920, 600), Qt.AspectRatioMode.KeepAspectRatio))
                self.original_image = QPixmap.fromImage(reader.read())
            else:
                self.original_image = QPixmap()
        if key != self.image_key:
            self.image_key = key
            self.image_pixmap = self.original_image.scaled(self.size(), Qt.AspectRatioMode.KeepAspectRatioByExpanding, Qt.TransformationMode.SmoothTransformation) if not self.original_image.isNull() else QPixmap()
        if not self.image_pixmap.isNull():
            p.drawPixmap(0, 0, self.image_pixmap)
            p.fillPath(path, QColor(0, 0, 0, 75))
        p.setClipping(False)
        p.setPen(QColor(255, 255, 255, 55))
        p.drawPath(path)
        font = self.state['font']
        fg, val = QColor(self.state['text_color']), QColor(self.state['value_color'])
        from datetime import datetime
        system = self.system_usage if self.state.get('usage_source') == 'windows' else None
        if system and (system['day'] != datetime.now().strftime('%Y-%m-%d') or system['month'] != datetime.now().strftime('%Y-%m')):
            system = None
        daily = system['daily'] if system else self.state['daily']
        monthly = system['monthly'] if system else self.state['monthly']
        remaining = max(0, self.state['limit_gb'] * 1024**3 - monthly)
        labels = {'speed':'当前下载速度', 'daily':'今日已用', 'remaining':'本月剩余'}
        values = {'speed':f'{size(self.speed)}/s', 'daily':size(daily), 'remaining':remaining_text(remaining)}
        preferred = self.state.get('small_field', 'remaining')
        if compact:
            field = preferred if preferred in labels else 'remaining'
            p.setPen(fg); p.setFont(QFont(font, 9)); p.drawText(QRectF(0, 18, self.width(), 22), Qt.AlignmentFlag.AlignCenter, labels[field])
            p.setPen(val)
            self.draw_fitted(p, QRectF(8, 43, self.width()-16, 37), values[field], font, 12, 7, Qt.AlignmentFlag.AlignCenter)
        else:
            fields, direction = layout_for(self.width(), self.height(), preferred)
            footer = self.height() >= 165 and direction == 'vertical'
            body_height = self.height() - (27 if footer else 6)
            margin = 6 if self.height() < 60 else 10
            width = self.width() - 2 * margin - 3
            row_height = body_height / len(fields) if direction == 'vertical' else body_height
            column_width = width / len(fields) if direction == 'horizontal' else width
            show_labels = self.width() >= 250 and row_height >= 34 and direction == 'vertical'
            for index, field in enumerate(fields):
                y = 3 + (index * row_height if direction == 'vertical' else 0)
                x = margin + (index * column_width if direction == 'horizontal' else 0)
                row = QRectF(x, y, column_width - 2, row_height)
                if show_labels:
                    label_width = row.width() * 0.49
                    p.setPen(fg)
                    self.draw_fitted(p, QRectF(row.x(), y, label_width, row_height), labels[field], font, 10, 7, Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft)
                    value_rect = QRectF(row.x()+label_width, y, row.width()-label_width, row_height)
                    align = Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignRight
                else:
                    value_rect = row
                    align = Qt.AlignmentFlag.AlignCenter
                p.setPen(val)
                self.draw_fitted(p, value_rect, values[field], font, min(15, max(7, int(row_height*.42))), 6, align)
            if footer:
                p.setPen(fg); p.setFont(QFont(font, 8))
                label = 'Windows 当前连接' if system else ('Windows 暂不可用 · 本机统计' if self.state.get('usage_source') == 'windows' else '本机统计 · 收发合计')
                p.drawText(QRectF(margin, self.height()-23, self.width()-2*margin-12, 16), Qt.AlignmentFlag.AlignLeft, QFontMetrics(p.font()).elidedText(label, Qt.TextElideMode.ElideRight, self.width()-2*margin-12))
            p.setPen(fg)
            p.drawLine(self.width()-11, self.height()-4, self.width()-4, self.height()-11)
        p.end()

    @staticmethod
    def draw_fitted(painter, rect, value, family, preferred, minimum, alignment):
        for points in range(preferred, minimum-1, -1):
            font = QFont(family, points, QFont.Weight.DemiBold)
            if QFontMetrics(font).horizontalAdvance(value) <= rect.width():
                painter.setFont(font)
                painter.drawText(rect, alignment, value)
                return
        painter.setFont(QFont(family, minimum))
        painter.drawText(rect, alignment, QFontMetrics(painter.font()).elidedText(value, Qt.TextElideMode.ElideRight, int(rect.width())))

    def mouseDoubleClickEvent(self, event):
        self.state['compact'] = not self.state['compact']
        self.resize(112, 112) if self.state['compact'] else self.resize(min(self.MAX_WIDTH, max(self.MIN_WIDTH, self.state['width'])), min(self.MAX_HEIGHT, max(self.MIN_HEIGHT, self.state['height'])))
        self.snap()
        self.update()
        from .storage import save
        save(self.state)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            if not self.state['compact'] and event.position().x() >= self.width()-16 and event.position().y() >= self.height()-16:
                self.resizing = True
                self.resize_origin = (event.globalPosition().toPoint(), self.size())
            else:
                self.drag = event.globalPosition().toPoint() - self.frameGeometry().topLeft()

    def mouseMoveEvent(self, event):
        if self.resizing:
            origin, previous = self.resize_origin
            delta = event.globalPosition().toPoint() - origin
            screen = QApplication.screenAt(event.globalPosition().toPoint()) or QApplication.primaryScreen()
            area = screen.geometry()
            maximum_width = min(self.MAX_WIDTH, max(self.MIN_WIDTH, area.right() - self.x() + 1))
            maximum_height = min(self.MAX_HEIGHT, max(self.MIN_HEIGHT, area.bottom() - self.y() + 1))
            self.resize(min(maximum_width, max(self.MIN_WIDTH, previous.width()+delta.x())), min(maximum_height, max(self.MIN_HEIGHT, previous.height()+delta.y())))
        elif self.drag is not None:
            self.move(event.globalPosition().toPoint() - self.drag)
        elif not self.state['compact'] and event.position().x() >= self.width()-16 and event.position().y() >= self.height()-16:
            self.setCursor(Qt.CursorShape.SizeFDiagCursor)
        else:
            self.unsetCursor()

    def mouseReleaseEvent(self, event):
        if self.drag is not None or self.resizing:
            self.drag = None
            self.resizing = False
            self.resize_origin = None
            self.snap()
            if not self.state['compact']:
                self.state['width'], self.state['height'] = self.width(), self.height()
            from .storage import save
            save(self.state)

    def snap(self):
        screen = (QApplication.screenAt(QCursor.pos()) or
                  QApplication.screenAt(self.frameGeometry().center()) or
                  QApplication.primaryScreen())
        # No magnetic snapping. Keep only a small draggable part on screen.
        area = screen.geometry()
        x, y = self.x(), self.y()
        x, y = keep_reachable(x, y, self.width(), self.height(),
                              area.left(), area.top(), area.right(), area.bottom())
        self.move(x, y)
        self.state['x'], self.state['y'] = x, y

    def changeEvent(self, event):
        if event.type() == QEvent.Type.WindowStateChange and self.windowState() & (Qt.WindowState.WindowMaximized | Qt.WindowState.WindowFullScreen):
            self.setWindowState(Qt.WindowState.WindowNoState)
            if self.state['compact']:
                self.resize(112, 112)
            else:
                self.resize(min(self.MAX_WIDTH, max(self.MIN_WIDTH, self.state['width'])), min(self.MAX_HEIGHT, max(self.MIN_HEIGHT, self.state['height'])))
            self.snap()
        super().changeEvent(event)
