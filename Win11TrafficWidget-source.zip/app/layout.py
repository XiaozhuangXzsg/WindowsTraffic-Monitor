"""Size-dependent layout decisions without any GUI imports."""

FIELDS = ('speed', 'daily', 'remaining')


def layout_for(width, height, preferred='remaining'):
    preferred = preferred if preferred in FIELDS else 'remaining'
    if height >= 60 and width >= 108:
        return FIELDS, 'vertical'
    if width >= 258 and height >= 28:
        return FIELDS, 'horizontal'
    if height >= 42 and width >= 108:
        return (('speed', 'remaining') if preferred == 'remaining' else (preferred, 'remaining')), 'vertical'
    if width >= 166 and height >= 28:
        return (('speed', 'remaining') if preferred == 'remaining' else (preferred, 'remaining')), 'horizontal'
    return (preferred,), 'horizontal'


def remaining_text(bytes_left):
    return f'{max(0, bytes_left) / (1024 ** 3):.2f} GB'
