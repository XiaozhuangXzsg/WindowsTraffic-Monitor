import sys
import winreg
from pathlib import Path

KEY = r'Software\Microsoft\Windows\CurrentVersion\Run'
NAME = 'Win11TrafficWidget'


def set_enabled(enabled):
    with winreg.CreateKeyEx(winreg.HKEY_CURRENT_USER, KEY, 0, winreg.KEY_SET_VALUE) as key:
        if enabled:
            if getattr(sys, 'frozen', False):
                command = f'"{sys.executable}" --quiet'
            else:
                main = Path(__file__).resolve().parents[1] / 'main.py'
                pythonw = Path(sys.executable).with_name('pythonw.exe')
                command = f'"{pythonw if pythonw.exists() else sys.executable}" "{main}" --quiet'
            winreg.SetValueEx(key, NAME, 0, winreg.REG_SZ, command)
        else:
            try:
                winreg.DeleteValue(key, NAME)
            except FileNotFoundError:
                pass


def is_enabled():
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, KEY) as key:
            winreg.QueryValueEx(key, NAME)
            return True
    except FileNotFoundError:
        return False
