from datetime import datetime
from time import monotonic
import psutil
from .storage import save


class Monitor:
    def __init__(self, state):
        self.state = state
        self.last_time = monotonic()
        self.last_recv = None
        self.reset_periods()
        self.sample(initial=True)

    def reset_periods(self):
        now = datetime.now()
        day, month = now.strftime('%Y-%m-%d'), now.strftime('%Y-%m')
        if self.state['day'] != day:
            self.state['_period_changed'] = True
            self.state['day'], self.state['daily'] = day, 0
        if self.state['month'] != month:
            self.state['_period_changed'] = True
            self.state['month'], self.state['monthly'] = month, 0
        if self.state.pop("_period_changed", False):
            save(self.state)

    def sample(self, initial=False):
        old_day, old_month = self.state['day'], self.state['month']
        self.reset_periods()
        counters = psutil.net_io_counters()
        total = counters.bytes_recv + counters.bytes_sent
        recv = counters.bytes_recv
        old = self.state.get('last_total')
        now = monotonic()
        elapsed = max(now - self.last_time, 0.001)
        delta = max(0, total - old) if isinstance(old, int) and total >= old else 0
        # Restart, reset, and clock-boundary intervals are baselined conservatively.
        if initial or old_day != self.state['day'] or old_month != self.state['month']:
            delta = 0
        recv_delta = max(0, recv - self.last_recv) if self.last_recv is not None and recv >= self.last_recv else 0
        if initial or old_day != self.state['day'] or old_month != self.state['month']:
            recv_delta = 0
        self.last_recv = recv
        self.last_time = now
        self.state['last_total'] = total
        self.state['daily'] += delta
        self.state['monthly'] += delta
        return recv_delta / elapsed if not initial else 0


def size(n):
    n = max(0, n)
    for unit in ('B', 'KB', 'MB', 'GB', 'TB'):
        if n < 1024 or unit == 'TB':
            return f'{n:.1f} {unit}'
        n /= 1024
